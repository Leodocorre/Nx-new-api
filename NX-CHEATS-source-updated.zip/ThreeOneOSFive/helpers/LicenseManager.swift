import Foundation
import Security
import UIKit

/// Remote license gate for NX CHEATS.
///
/// Keys follow `NX-CHEATS-XXXXXXXXXXX`. Their validity is determined by the
/// public license panel endpoint and includes both revocation and expiration.
@MainActor
final class LicenseManager: ObservableObject {

    static let shared = LicenseManager()

    private static let keychainService = "com.nxcheats.license"
    private static let keychainAccount = "active_license"
    private static let keyPrefix = "NX-CHEATS-"
    private static let validationBaseURLKey = "LicenseValidationBaseURL"
    /// URL fixa de configuração. O JSON pode apontar para qualquer domínio da API
    /// sem exigir uma nova compilação da IPA.
    private static let remoteConfigURL = URL(string: "https://raw.githubusercontent.com/Leodocorre/new-nx/main/license-config.json")!
    /// Fallback se a configuração remota e o Info.plist não estiverem disponíveis.
    private static let defaultValidationBaseURL = "https://nxcheatsgenerator.discloud.dev"
    private static let cachedBaseURLKey = "CachedLicenseValidationBaseURL"

    @Published private(set) var isLicensed: Bool
    @Published private(set) var maskedLicense: String?
    @Published private(set) var activatedAt: Date?
    @Published private(set) var expiresAt: Date?
    @Published private(set) var isRefreshing = false
    private var expiryTask: Task<Void, Never>?

    private init() {
        if let stored = Self.loadFromKeychain() {
            maskedLicense = Self.mask(stored.key)
            activatedAt = stored.activatedAt
            expiresAt = stored.expiresAt
            isLicensed = stored.expiresAt > Date() && Self.isValidFormat(stored.key)
        } else {
            isLicensed = false
            maskedLicense = nil
            activatedAt = nil
            expiresAt = nil
        }
        scheduleExpiryGuard()
    }

    enum ActivateError: LocalizedError {
        case empty
        case invalidFormat
        case endpointUnavailable
        case connectionFailed
        case invalidOrExpired
        case keychainFailed

        var errorDescription: String? {
            switch self {
            case .empty:
                return "Informe uma key de licença."
            case .invalidFormat:
                return "A key deve seguir o formato NX-CHEATS-XXXXXXXXXXX."
            case .endpointUnavailable:
                return "O endereço de validação de licença não está configurado."
            case .connectionFailed:
                return "Não foi possível consultar a licença. Verifique sua conexão e tente novamente."
            case .invalidOrExpired:
                return "Esta licença está inválida, revogada ou expirada."
            case .keychainFailed:
                return "Não foi possível salvar a licença neste dispositivo."
            }
        }
    }

    @discardableResult
    func activate(rawKey: String) async throws -> Bool {
        let key = Self.normalize(rawKey)
        guard !key.isEmpty else { throw ActivateError.empty }
        guard Self.isValidFormat(key) else { throw ActivateError.invalidFormat }

        let validation = try await Self.requestValidation(for: key)
        guard validation.status == "valid", let remoteExpiry = validation.expiresAt, remoteExpiry > Date() else {
            throw ActivateError.invalidOrExpired
        }

        let now = Date()
        try Self.saveToKeychain(key: key, activatedAt: now, expiresAt: remoteExpiry)
        applyLicensedState(key: key, activatedAt: now, expiresAt: remoteExpiry)
        return true
    }

    /// Refreshes the stored license when the app opens or returns to the foreground.
    /// A temporary network failure never grants access and does not discard a stored key.
    func refreshValidation() async {
        guard let stored = Self.loadFromKeychain() else { return }
        isRefreshing = true
        defer { isRefreshing = false }

        do {
            let validation = try await Self.requestValidation(for: stored.key)
            guard validation.status == "valid", let remoteExpiry = validation.expiresAt, remoteExpiry > Date() else {
                applyUnlicensedState(using: stored)
                return
            }

            try Self.saveToKeychain(key: stored.key, activatedAt: stored.activatedAt, expiresAt: remoteExpiry)
            applyLicensedState(key: stored.key, activatedAt: stored.activatedAt, expiresAt: remoteExpiry)
        } catch {
            // Keep the local state only until its known server-issued expiration.
            enforceLocalExpiration()
        }
    }

    /// Immediately closes the licensed state when the persisted UTC expiration passes.
    func enforceLocalExpiration(now: Date = Date()) {
        guard let expiresAt, expiresAt <= now else { return }
        expiryTask?.cancel()
        expiryTask = nil
        isLicensed = false
    }

    func deactivate() {
        expiryTask?.cancel()
        expiryTask = nil
        try? Self.deleteFromKeychain()
        isLicensed = false
        maskedLicense = nil
        activatedAt = nil
        expiresAt = nil
    }

    static func normalize(_ raw: String) -> String {
        raw.uppercased()
            .replacingOccurrences(of: " ", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func isValidFormat(_ key: String) -> Bool {
        let pattern = "^NX-CHEATS-[A-Z0-9]{11}$"
        return key.range(of: pattern, options: .regularExpression) != nil
    }

    static func mask(_ key: String) -> String {
        guard key.count > keyPrefix.count + 4 else { return "NX-CHEATS-••••" }
        return "\(keyPrefix)•••••••\(key.suffix(4))"
    }

    private func applyLicensedState(key: String, activatedAt: Date, expiresAt: Date) {
        isLicensed = true
        maskedLicense = Self.mask(key)
        self.activatedAt = activatedAt
        self.expiresAt = expiresAt
        scheduleExpiryGuard()
    }

    private func applyUnlicensedState(using stored: StoredLicense) {
        expiryTask?.cancel()
        expiryTask = nil
        isLicensed = false
        maskedLicense = Self.mask(stored.key)
        activatedAt = stored.activatedAt
        expiresAt = stored.expiresAt
    }

    private func scheduleExpiryGuard() {
        expiryTask?.cancel()
        guard let expiresAt, expiresAt > Date() else {
            enforceLocalExpiration()
            return
        }
        let delay = UInt64(max(0, expiresAt.timeIntervalSinceNow * 1_000_000_000))
        expiryTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: delay)
            guard !Task.isCancelled else { return }
            self?.enforceLocalExpiration()
        }
    }

    private struct RemoteLicenseConfig: Decodable {
        let configVersion: Int?
        let apiBaseURL: String
    }

    private static func resolvedValidationBaseURL() async -> String {
        if let remoteURL = try? await fetchRemoteBaseURL() {
            UserDefaults.standard.set(remoteURL, forKey: cachedBaseURLKey)
            return remoteURL
        }

        if let cached = UserDefaults.standard.string(forKey: cachedBaseURLKey),
           isUsableBaseURL(cached) {
            return cached
        }

        if let fromPlist = Bundle.main.object(forInfoDictionaryKey: validationBaseURLKey) as? String,
           isUsableBaseURL(fromPlist) {
            return fromPlist
        }
        return defaultValidationBaseURL
    }

    private static func fetchRemoteBaseURL() async throws -> String {
        var request = URLRequest(url: remoteConfigURL)
        request.httpMethod = "GET"
        request.timeoutInterval = 8
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            throw ActivateError.connectionFailed
        }
        let config = try JSONDecoder().decode(RemoteLicenseConfig.self, from: data)
        guard isUsableBaseURL(config.apiBaseURL) else {
            throw ActivateError.endpointUnavailable
        }
        return config.apiBaseURL.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }

    private static func isUsableBaseURL(_ value: String) -> Bool {
        guard let url = URL(string: value.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme?.lowercased() == "https",
              url.host != nil,
              !value.contains("$(") else { return false }
        return true
    }

    private struct ValidationPayload: Decodable {
        let status: String
        let expiresAt: String?
        let remainingSeconds: Int?

        var parsedExpiry: Date? {
            guard let expiresAt else { return nil }
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let d = formatter.date(from: expiresAt) { return d }
            // Fallback sem fracao de segundo
            let plain = ISO8601DateFormatter()
            plain.formatOptions = [.withInternetDateTime]
            return plain.date(from: expiresAt)
        }
    }

    private struct ValidationResult {
        let status: String
        let expiresAt: Date?
    }

    private static func deviceIdentifier() -> String {
        if let idfv = UIDevice.current.identifierForVendor?.uuidString {
            return idfv
        }
        return "unknown"
    }

    private static func requestValidation(for key: String) async throws -> ValidationResult {
        let baseURLString = await resolvedValidationBaseURL()
        guard let baseURL = URL(string: baseURLString),
              baseURL.scheme?.lowercased() == "https",
              baseURL.host != nil else {
            throw ActivateError.endpointUnavailable
        }

        let endpoint = baseURL.appendingPathComponent("api/license/validate")
        guard var components = URLComponents(url: endpoint, resolvingAgainstBaseURL: false) else {
            throw ActivateError.endpointUnavailable
        }
        components.queryItems = [
            URLQueryItem(name: "key", value: key),
            URLQueryItem(name: "udid", value: deviceIdentifier())
        ]
        guard let url = components.url else { throw ActivateError.endpointUnavailable }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 15
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else {
                throw ActivateError.connectionFailed
            }
            let payload = try JSONDecoder().decode(ValidationPayload.self, from: data)
            return ValidationResult(status: payload.status, expiresAt: payload.parsedExpiry)
        } catch let error as ActivateError {
            throw error
        } catch {
            throw ActivateError.connectionFailed
        }
    }

    private struct StoredLicense {
        let key: String
        let activatedAt: Date
        let expiresAt: Date
    }

    private static func saveToKeychain(key: String, activatedAt: Date, expiresAt: Date) throws {
        let payload: [String: Any] = [
            "key": key,
            "activatedAt": activatedAt.timeIntervalSince1970,
            "expiresAt": expiresAt.timeIntervalSince1970
        ]
        let data = try JSONSerialization.data(withJSONObject: payload)

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount
        ]
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]

        let update = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if update == errSecSuccess { return }
        guard update == errSecItemNotFound else { throw ActivateError.keychainFailed }

        var item = query
        attributes.forEach { item[$0.key] = $0.value }
        guard SecItemAdd(item as CFDictionary, nil) == errSecSuccess else {
            throw ActivateError.keychainFailed
        }
    }

    private static func loadFromKeychain() -> StoredLicense? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let data = result as? Data,
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let key = json["key"] as? String,
              let activatedAtTimestamp = json["activatedAt"] as? TimeInterval,
              let expiresAtTimestamp = json["expiresAt"] as? TimeInterval else {
            return nil
        }
        return StoredLicense(
            key: key,
            activatedAt: Date(timeIntervalSince1970: activatedAtTimestamp),
            expiresAt: Date(timeIntervalSince1970: expiresAtTimestamp)
        )
    }

    private static func deleteFromKeychain() throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: keychainAccount
        ]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw ActivateError.keychainFailed
        }
    }
}
