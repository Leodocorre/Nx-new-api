import SwiftUI
import UIKit

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @StateObject private var patchStore = PatchProjectStore()
    @StateObject private var repositoryStore = PackageRepositoryStore()
    @StateObject private var appUpdateManager = AppUpdateManager()
    @ObservedObject private var licenseManager = LicenseManager.shared
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var showAttribution = false
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    init() {
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var isLicensed: Bool { licenseManager.isLicensed }
    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }


    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environmentObject(patchStore)
                    .environmentObject(repositoryStore)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .opacity(!isLicensed ? 0 : 1)
                    .allowsHitTesting(isLicensed)

                if !isLicensed {
                    LicenseActivationView()
                        .environment(\.appLanguage, language)
                        .environment(\.locale, language.locale)
                        .transition(.opacity.combined(with: .scale(scale: 0.98)))
                        .zIndex(2)
                }

                if isLicensed, appUpdateManager.isRequired {
                    MandatoryUpdateView(update: appUpdateManager)
                        .zIndex(3)
                }
            }
            .animation(.spring(response: 0.42, dampingFraction: 0.86), value: isLicensed)
            .preferredColorScheme(.dark)
            .displayIdentityAttribution(isPresented: $showAttribution, enabled: true)
            .sheet(isPresented: $showAttribution) {
                DisplayAttributionSheet()
            }
            .onAppear {
                Task { await licenseManager.refreshValidation() }
                Task { await appUpdateManager.check() }
                if isLicensed {
                    appState.detectSupport()
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active else { return }
                Task { await licenseManager.refreshValidation() }
                Task { await appUpdateManager.check() }
                if isLicensed { appState.detectSupport() }
            }
            .onChange(of: isLicensed) { licensed in
                if licensed {
                    appState.detectSupport()
                    Task { await appUpdateManager.check() }
                    Task { await repositoryStore.refreshAllAndWait() }
                }
            }
            .onOpenURL { url in
                patchDraftCoordinator.presentImport(url)
            }
        }
    }
}

@MainActor
final class AppUpdateManager: ObservableObject {
    @Published private(set) var isRequired = false
    @Published private(set) var title = "Atualização obrigatória"
    @Published private(set) var message = "Atualize a IPA para continuar usando o aplicativo."
    @Published private(set) var minimumVersion = ""
    @Published private(set) var downloadURL: URL?
    private var isChecking = false

    private var currentVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "0"
    }

    func check() async {
        guard !isChecking, let baseURL = await LicenseManager.resolvedAPIBaseURL() else { return }
        guard var components = URLComponents(url: baseURL.appendingPathComponent("api/ipa/update"), resolvingAgainstBaseURL: false) else { return }
        components.queryItems = [URLQueryItem(name: "version", value: currentVersion)]
        guard let url = components.url, url.scheme?.lowercased() == "https" else { return }
        isChecking = true
        defer { isChecking = false }
        var request = URLRequest(url: url)
        request.timeoutInterval = 12
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        guard let (data, response) = try? await URLSession.shared.data(for: request),
              let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode),
              let payload = try? JSONDecoder().decode(AppUpdatePayload.self, from: data) else { return }
        title = payload.title
        message = payload.message
        minimumVersion = payload.minimumVersion
        downloadURL = payload.downloadURL.flatMap(URL.init(string:))
        isRequired = payload.required && downloadURL != nil
    }

    func openDownload() {
        guard let downloadURL else { return }
        UIApplication.shared.open(downloadURL)
    }

    private struct AppUpdatePayload: Decodable {
        let required: Bool
        let minimumVersion: String
        let downloadURL: String?
        let title: String
        let message: String
    }
}

private struct MandatoryUpdateView: View {
    @ObservedObject var update: AppUpdateManager

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 18) {
                Image(systemName: "arrow.down.app.fill")
                    .font(.system(size: 54, weight: .bold))
                    .foregroundStyle(.red)
                Text(update.title)
                    .font(.title2.weight(.bold))
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                Text(update.message)
                    .font(.body)
                    .foregroundStyle(.white.opacity(0.72))
                    .multilineTextAlignment(.center)
                Text("Versão mínima: \(update.minimumVersion)")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.52))
                Button("Atualizar agora") {
                    update.openDownload()
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
            }
            .padding(28)
            .frame(maxWidth: 360)
        }
        .interactiveDismissDisabled(true)
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}
