import SwiftUI
import UIKit
import ImageIO

/// Lightweight animated GIF renderer used by the catalog and license screen.
struct AnimatedGIFView: UIViewRepresentable {
    let data: Data?
    var cornerRadius: CGFloat = 14
    var contentMode: UIView.ContentMode = .scaleAspectFit

    func makeUIView(context: Context) -> UIImageView {
        let view = UIImageView()
        // Aspect fit preserva a proporção original do GIF; nunca usar resize
        // livre dentro dos quadrados do cabeçalho e dos cards.
        view.contentMode = .scaleAspectFit
        view.layer.contentsGravity = .resizeAspect
        view.clipsToBounds = true
        view.layer.cornerRadius = cornerRadius
        view.backgroundColor = UIColor.black.withAlphaComponent(0.18)
        view.accessibilityIgnoresInvertColors = true
        return view
    }

    func updateUIView(_ view: UIImageView, context: Context) {
        view.contentMode = .scaleAspectFit
        view.layer.contentsGravity = .resizeAspect
        guard let data else {
            view.image = UIImage(systemName: "shippingbox.fill")
            return
        }
        view.image = Self.animatedImage(data: data) ?? UIImage(data: data)
    }

    private static func animatedImage(data: Data) -> UIImage? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil) else { return nil }
        let frameCount = min(CGImageSourceGetCount(source), 80)
        guard frameCount > 0 else { return nil }

        var frames: [UIImage] = []
        var duration: Double = 0
        frames.reserveCapacity(frameCount)

        for index in 0..<frameCount {
            guard let cgImage = CGImageSourceCreateImageAtIndex(source, index, nil) else { continue }
            let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [CFString: Any]
            let gif = properties?[kCGImagePropertyGIFDictionary] as? [CFString: Any]
            let unclamped = gif?[kCGImagePropertyGIFUnclampedDelayTime] as? Double
            let clamped = gif?[kCGImagePropertyGIFDelayTime] as? Double
            let frameDelay = max(0.04, unclamped ?? clamped ?? 0.1)
            duration += frameDelay
            frames.append(UIImage(cgImage: cgImage))
        }

        guard !frames.isEmpty else { return nil }
        if frames.count == 1 { return frames[0] }
        return UIImage.animatedImage(with: frames, duration: max(duration, 0.1))
    }
}

@MainActor
final class AnimatedGIFDataLoader: ObservableObject {
    @Published private(set) var data: Data?
    @Published private(set) var isLoading = false
    private var loadedURL: URL?

    func load(url: URL?) async {
        guard let url else { return }
        guard loadedURL != url else { return }
        loadedURL = url
        isLoading = true
        defer { isLoading = false }

        if let localURL = Bundle.main.url(forResource: "product-animation", withExtension: "gif"),
           url.isFileURL {
            data = try? Data(contentsOf: localURL)
            return
        }

        guard url.scheme?.lowercased() == "https" else { return }
        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        request.setValue("3105", forHTTPHeaderField: "User-Agent")
        guard let (loaded, response) = try? await URLSession.shared.data(for: request),
              let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode),
              loaded.count <= 16 * 1_024 * 1_024 else { return }
        data = loaded
    }
}

struct PremiumCatalogView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var repositoryStore: PackageRepositoryStore
    @EnvironmentObject private var patchStore: PatchProjectStore
    @ObservedObject private var license = LicenseManager.shared
    @StateObject private var headerGIFLoader = AnimatedGIFDataLoader()
    @StateObject private var resellerIconLoader = AnimatedGIFDataLoader()
    @State private var selectedCategory = "Todos"
    @State private var isRefreshing = false
    @State private var licenseNow = Date()
    @State private var showSettings = false
    @State private var showLogs = false

    let onOpenSettings: () -> Void
    let onOpenLogs: () -> Void

    private var categories: [String] {
        let remoteCategories = Set(repositoryStore.packages.compactMap { package in
            let value = package.package.category?.trimmingCharacters(in: .whitespacesAndNewlines)
            return value?.isEmpty == false ? value : nil
        })
        return ["Todos"] + remoteCategories.sorted {
            $0.localizedCaseInsensitiveCompare($1) == .orderedAscending
        }
    }

    private var products: [RepositoryPackageRecord] {
        let all = repositoryStore.packages
        guard selectedCategory != "Todos" else { return all }
        return all.filter { ($0.package.category ?? "Outros") == selectedCategory }
    }

    private var headerIconData: Data? {
        if license.resellerIconURL != nil {
            return resellerIconLoader.data ?? headerGIFLoader.data
        }
        return headerGIFLoader.data
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 18) {
                    header
                    deviceStatus
                    categoryGrid
                    productSection
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 34)
            }
            .background(AppTheme.pageBackground.ignoresSafeArea())
            .navigationBarHidden(true)
            .refreshable { await refreshCatalog() }
            .task { repositoryStore.refreshAllIfNeeded() }
            .onChange(of: repositoryStore.packages.count) { _ in
                if !categories.contains(selectedCategory) {
                    selectedCategory = "Todos"
                }
            }
            .onReceive(Timer.publish(every: 1, on: .main, in: .common).autoconnect()) { now in
                licenseNow = now
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showLogs) { LogView() }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack(spacing: 12) {
            if let data = headerIconData {
                AnimatedGIFView(data: data, cornerRadius: 12, contentMode: .scaleAspectFit)
                    .frame(width: 62, height: 62)
                    .aspectRatio(1, contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            } else {
                AppLogo(size: 42)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(license.resellerName ?? "NXFF4X EXTERNAL")
                    .font(.system(size: 17, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text("Produtos e atualizações online")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.55))
            }
            Spacer()
            Button(action: onOpenSettings) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.82))
                    .frame(width: 38, height: 38)
                    .background(Color.white.opacity(0.08), in: Circle())
            }
            .buttonStyle(.plain)
        }
        .task {
            if let gifURL = Bundle.main.url(forResource: "product-animation", withExtension: "gif") {
                await headerGIFLoader.load(url: gifURL)
            }
        }
        .task(id: license.resellerIconURL) {
            await resellerIconLoader.load(url: license.resellerIconURL)
        }
    }

    private var deviceStatus: some View {
        HStack(spacing: 10) {
            statusPill(title: "iOS", value: AppInfo.osVersion, color: .white)
            statusPill(title: "Device", value: AppInfo.machineName, color: .white)
            statusPill(
                title: "Support",
                value: appState.isSupported ? "SUPPORTED" : "UNSUPPORTED",
                color: appState.isSupported ? .green : .red
            )
            statusPill(title: "Key", value: licenseRemainingLabel, color: .green)
        }
    }

    private var licenseRemainingLabel: String {
        guard let expiry = license.expiresAt else { return "—" }
        let seconds = max(0, Int(expiry.timeIntervalSince(licenseNow)))
        guard seconds > 0 else { return "EXPIRADA" }
        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60
        let remainingSeconds = seconds % 60
        if days > 0 { return "\(days)d \(hours)h" }
        if hours > 0 { return "\(hours)h \(minutes)m" }
        return "\(minutes)m \(remainingSeconds)s"
    }

    private func statusPill(title: String, value: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title.uppercased())
                .font(.system(size: 9, weight: .bold))
                .foregroundStyle(.white.opacity(0.42))
            Text(value)
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 10)
        .padding(.vertical, 9)
        .background(Color.white.opacity(0.065), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }

    private var categoryGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
            ForEach(categories, id: \.self) { category in
                Button { withAnimation(.easeInOut(duration: 0.18)) { selectedCategory = category } } label: {
                    Text(category)
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(selectedCategory == category ? .white : .white.opacity(0.6))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(selectedCategory == category ? AppTheme.accent : Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
    }

    @ViewBuilder
    private var productSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(selectedCategory.uppercased())
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(.white.opacity(0.66))
                Spacer()
                Button { Task { await refreshCatalog() } } label: {
                    Image(systemName: isRefreshing ? "arrow.triangle.2.circlepath" : "arrow.clockwise")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(AppTheme.accent)
                }
                .buttonStyle(.plain)
                .disabled(isRefreshing)
            }

            if products.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: repositoryStore.isRefreshing ? "arrow.triangle.2.circlepath" : "shippingbox")
                        .font(.system(size: 28))
                        .foregroundStyle(AppTheme.accent)
                    Text(repositoryStore.isRefreshing ? "Atualizando catálogo…" : "Nenhum produto disponível")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.72))
                    Text("Puxe a tela para atualizar ou tente novamente.")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.45))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 42)
                .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            } else {
                ForEach(products) { record in
                    PremiumProductRow(record: record) {
                        repositoryStore.install(record, using: patchStore)
                    }
                }
            }
        }
    }

    private func refreshCatalog() async {
        guard !isRefreshing else { return }
        isRefreshing = true
        await repositoryStore.refreshAllAndWait()
        isRefreshing = false
    }
}

private struct PremiumProductRow: View {
    let record: RepositoryPackageRecord
    let action: () -> Void
    @StateObject private var loader = AnimatedGIFDataLoader()

    var body: some View {
        HStack(spacing: 12) {
            AnimatedGIFView(data: loader.data, cornerRadius: 12, contentMode: .scaleAspectFit)
                .frame(width: 72, height: 72)
                .aspectRatio(1, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.accent.opacity(0.32), lineWidth: 1))

            VStack(alignment: .leading, spacing: 4) {
                Text(record.package.name)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(record.package.summary)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.55))
                    .lineLimit(2)
                HStack(spacing: 7) {
                    Text("v\(record.package.version)")
                    if let category = record.package.category { Text(category) }
                }
                .font(.system(size: 10, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.38))
            }

            Spacer(minLength: 6)

            Button(action: action) {
                Image(systemName: "arrow.down.circle.fill")
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(AppTheme.accent)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Baixar \(record.package.name)")
        }
        .padding(12)
        .background(Color.white.opacity(0.065), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.07), lineWidth: 1))
        .task {
            await loader.load(url: record.package.iconURL)
            if loader.data == nil,
               let fallback = Bundle.main.url(forResource: "product-animation", withExtension: "gif") {
                await loader.load(url: fallback)
            }
        }
    }
}
