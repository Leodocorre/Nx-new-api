import SwiftUI

/// Full-screen animated background with only the key field overlaid.
struct LicenseActivationView: View {
    @ObservedObject private var license = LicenseManager.shared

    @State private var keyInput = ""
    @State private var isBusy = false
    @FocusState private var fieldFocused: Bool

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 10) {
                TextField("Insert key", text: $keyInput)
                    .font(.system(.body, design: .monospaced))
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .keyboardType(.asciiCapable)
                    .submitLabel(.go)
                    .focused($fieldFocused)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 15)
                    .foregroundStyle(.white)
                    .tint(.white)
                    .background(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(Color.white.opacity(0.08))
                            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1))
                    )
                    .overlay {
                        if isBusy {
                            ProgressView()
                                .tint(.white)
                                .padding(.trailing, 14)
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        }
                    }

                Button(action: activate) {
                    Text("Activate")
                        .font(.body.weight(.semibold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .fill(canActivate ? Color.white.opacity(0.16) : Color.white.opacity(0.07))
                        )
                }
                .buttonStyle(.plain)
                .disabled(!canActivate || isBusy)
            }
            .padding(.horizontal, 24)
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                fieldFocused = true
            }
        }
    }

    private var canActivate: Bool {
        keyInput.trimmingCharacters(in: .whitespacesAndNewlines).count >= 10
    }

    private func activate() {
        guard canActivate, !isBusy else { return }
        isBusy = true
        fieldFocused = false
        Task {
            do {
                try await license.activate(rawKey: keyInput)
            } catch {
                fieldFocused = true
            }
            isBusy = false
        }
    }
}

#if DEBUG
struct LicenseActivationView_Previews: PreviewProvider {
    static var previews: some View {
        LicenseActivationView()
            .preferredColorScheme(.dark)
    }
}
#endif
