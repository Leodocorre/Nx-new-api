import SwiftUI

struct LicenseCountdownView: View {
    @ObservedObject private var license = LicenseManager.shared
    @State private var now = Date()
    private let timer = Timer.publish(every: 60, on: .main, in: .common).autoconnect()

    var body: some View {
        HStack(spacing: 7) {
            Circle().fill(AppTheme.accent).frame(width: 7, height: 7)
            Text(label)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white)
                .lineLimit(1)
        }
        .padding(.horizontal, 11)
        .padding(.vertical, 7)
        .background(Color.black.opacity(0.88), in: Capsule())
        .overlay(Capsule().stroke(AppTheme.accent.opacity(0.55), lineWidth: 1))
        .shadow(color: .black.opacity(0.3), radius: 8, y: 3)
        .onReceive(timer) { now = $0 }
        .accessibilityLabel(Text(label))
    }

    private var label: String {
        guard let expiry = license.expiresAt else { return "Licença ativa" }
        let seconds = max(0, Int(expiry.timeIntervalSince(now)))
        if seconds == 0 { return "Licença expirada" }
        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60
        if days > 0 { return "Licença: \(days)d \(hours)h" }
        if hours > 0 { return "Licença: \(hours)h \(minutes)m" }
        return "Licença: \(max(1, minutes))m"
    }
}
